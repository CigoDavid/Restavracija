<?php
require_once "db.php";

$vnosi = $pdo->query("SELECT * FROM kontakt ORDER BY id DESC")->fetchAll();

function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, "UTF-8"); }
?>
<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="utf-8">
    <title>Vpisane osebe | Restavracija Marlot</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Vpisane osebe (kontaktni obrazec)</h1>

<p>
    <a href="kontak.php" class="button">Kontaktni obrazec</a>
    <a href="index.html" class="button">Domača stran</a>
</p>

<p>Skupaj vnosov: <strong><?= count($vnosi) ?></strong></p>

<table>
    <tr>
        <th>ID</th>
        <th>Ime in priimek</th>
        <th>E-pošta</th>
        <th>Št. oseb</th>
        <th>Datum in čas</th>
        <th>Sporočilo</th>
        <th>Vneseno</th>
    </tr>

    <?php if (!$vnosi): ?>
    <tr><td colspan="7">Za zdaj ni nobenega vnosa.</td></tr>
    <?php endif; ?>

    <?php foreach ($vnosi as $v): ?>
    <tr>
        <td><?= e($v["id"]) ?></td>
        <td><?= e($v["ime"]) ?></td>
        <td><?= e($v["email"]) ?></td>
        <td><?= e($v["st_oseb"]) ?></td>
        <td><?= $v["datum_cas"] ? e(date("d.m.Y H:i", strtotime($v["datum_cas"]))) : "" ?></td>
        <td><?= nl2br(e($v["sporocilo"])) ?></td>
        <td><?= e(date("d.m.Y H:i", strtotime($v["vneseno"]))) ?></td>
    </tr>
    <?php endforeach; ?>
</table>

</body>
</html>
