<?php
// Povezava na MySQL (Laragon: uporabnik root, brez gesla)
$host     = "localhost";
$dbname   = "restavracija";
$username = "root";
$password = "";

try {
    // Najprej se povežemo brez baze, da jo lahko samodejno ustvarimo
    $pdo = new PDO(
        "mysql:host=$host;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$dbname`");

    // Tabela za vnose iz kontaktnega obrazca (ustvari se samodejno)
    $pdo->exec("CREATE TABLE IF NOT EXISTS kontakt (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        ime         VARCHAR(150) NOT NULL,
        email       VARCHAR(150) NOT NULL,
        st_oseb     INT NULL,
        datum_cas   DATETIME NULL,
        sporocilo   TEXT NULL,
        vneseno     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

} catch (PDOException $e) {
    die("Povezava z bazo ni uspela: " . htmlspecialchars($e->getMessage()));
}
